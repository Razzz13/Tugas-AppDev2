﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        MySqlConnection connect;
        MySqlCommand comnd;
        MySqlDataAdapter adptr;
        string query;
        DataTable tim = new DataTable();
        DataTable tim2 = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            connect = new MySqlConnection("server = localhost; uid = root; pwd = isbmantap; database = premier_league");
            connect.Open();
            connect.Close();

                query = "select team_name,team_id from team";
                comnd = new MySqlCommand(query,connect);
                adptr = new MySqlDataAdapter(comnd);
                adptr.Fill(tim);
                cb_teamHome.DataSource = tim;
                cb_teamHome.DisplayMember = "team_name";
                 cb_teamHome.ValueMember = "team_id";
                query = "select team_name,team_id from team";
                comnd = new MySqlCommand(query, connect);
                adptr = new MySqlDataAdapter(comnd);
                adptr.Fill(tim2);
                cb_teamAway.DataSource = tim2;
                cb_teamAway.DisplayMember = "team_name";
            cb_teamAway.ValueMember = "team_id";
        }

        private void cb_teamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable manager2 = new DataTable();
            DataTable captain2 = new DataTable();

            string query1 = $"select manager_name from manager,team where manager.manager_id = team.manager_id && team.team_id ='{cb_teamHome.SelectedValue}'";
            comnd = new MySqlCommand(query1, connect);
            adptr = new MySqlDataAdapter(comnd);
            adptr.Fill(manager2);
            if (manager2.Rows.Count != 0)
            {
                lbl_managerName2.Text = manager2.Rows[0][0].ToString();
            }

            string query2 = $"select player_name from player,team where player.player_id = team.captain_id && player.team_id = '{cb_teamHome.SelectedValue}'";
            comnd = new MySqlCommand(query2, connect);
            adptr = new MySqlDataAdapter(comnd);
            adptr.Fill(captain2);
            if (captain2.Rows.Count != 0)
            {
                lbl_captainName2.Text = captain2.Rows[0][0].ToString();
            }
        }

        private void cb_teamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable manager1 = new DataTable();
            DataTable captain1 = new DataTable();

            string query1 = $"select manager_name from manager,team where manager.manager_id = team.manager_id && team.team_id ='{cb_teamHome.SelectedValue}'";
            comnd = new MySqlCommand(query1,connect);
            adptr = new MySqlDataAdapter(comnd);
            adptr.Fill(manager1);
            if (manager1.Rows.Count != 0)
            {
                lbl_managerName1.Text = manager1.Rows[0][0].ToString();
            }

            string query2 = $"select player_name from player,team where player.player_id = team.captain_id && player.team_id = '{cb_teamHome.SelectedValue}'";
            comnd = new MySqlCommand(query2, connect);
            adptr = new MySqlDataAdapter(comnd);
            adptr.Fill(captain1);
            if (captain1.Rows.Count != 0)
            {
                lbl_captainName1.Text = captain1.Rows[0][0].ToString();
            }

            DataTable capacity = new DataTable();
            string query3 = $"select capacity from team where team_id = '{cb_teamHome.SelectedValue}'";
            comnd = new MySqlCommand(query3, connect);
            adptr = new MySqlDataAdapter(comnd);
            adptr.Fill(capacity);
            if (capacity.Rows.Count != 0)
            {
                lbl_capacityCount.Text = capacity.Rows[0][0].ToString();
            }

            DataTable stadiun = new DataTable();
            string query4 = $"select home_stadium from team where team_id = '{cb_teamHome.SelectedValue}'";
            comnd = new MySqlCommand(query4, connect);
            adptr = new MySqlDataAdapter(comnd);
            adptr.Fill(stadiun);
            if (stadiun.Rows.Count != 0)
            {
                lbl_stadiunName.Text = stadiun.Rows[0][0].ToString();
            }
        }

        private void btn_check_Click(object sender, EventArgs e)
        {
            DataTable tgl = new DataTable();
            string query1 = $"select concat(day(match_date),' ',date_format(match_date,'%M'),' ',Year(match_date)) from `match` where team_home = '{cb_teamHome.SelectedValue}' && team_away = '{cb_teamAway.SelectedValue}'";
            comnd = new MySqlCommand(query1, connect);
            adptr = new MySqlDataAdapter(comnd);
            adptr.Fill(tgl);
            if (tgl.Rows.Count != 0)
            {
                lbl_tanggalTanding.Text = tgl.Rows[0][0].ToString();
            }

            DataTable skorHome = new DataTable();
            string query2 = $"select goal_home from `match` where team_home = '{cb_teamHome.SelectedValue}'";
            comnd = new MySqlCommand(query2, connect);
            adptr = new MySqlDataAdapter(comnd);
            adptr.Fill(skorHome);
            if (skorHome.Rows.Count != 0)
            {
                lbl_skorHome.Text = skorHome.Rows[0][0].ToString();
            }

            DataTable skorAway = new DataTable();
            string query3 = $"select goal_away from `match` where team_away = '{cb_teamAway.SelectedValue}'";
            comnd = new MySqlCommand(query3, connect);
            adptr = new MySqlDataAdapter(comnd);
            adptr.Fill(skorAway);
            if (skorAway.Rows.Count != 0)
            {
                lbl_skorAway.Text = skorAway.Rows[0][0].ToString();
            }
        }
    }
}
