﻿namespace WindowsFormsApp4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cb_teamHome = new System.Windows.Forms.ComboBox();
            this.cb_teamAway = new System.Windows.Forms.ComboBox();
            this.lbl_vs = new System.Windows.Forms.Label();
            this.lbl_manager1 = new System.Windows.Forms.Label();
            this.lbl_manager2 = new System.Windows.Forms.Label();
            this.lbl_managerName1 = new System.Windows.Forms.Label();
            this.lbl_managerName2 = new System.Windows.Forms.Label();
            this.lbl_captain1 = new System.Windows.Forms.Label();
            this.lbl_captainName1 = new System.Windows.Forms.Label();
            this.lbl_captain2 = new System.Windows.Forms.Label();
            this.lbl_captainName2 = new System.Windows.Forms.Label();
            this.lbl_stadium = new System.Windows.Forms.Label();
            this.lbl_capacity = new System.Windows.Forms.Label();
            this.lbl_stadiunName = new System.Windows.Forms.Label();
            this.lbl_capacityCount = new System.Windows.Forms.Label();
            this.lbl_skorHome = new System.Windows.Forms.Label();
            this.lbl_tanggalTanding = new System.Windows.Forms.Label();
            this.lbl_skor = new System.Windows.Forms.Label();
            this.lbl_tanggal = new System.Windows.Forms.Label();
            this.btn_check = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_skorAway = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // cb_teamHome
            // 
            this.cb_teamHome.FormattingEnabled = true;
            this.cb_teamHome.Location = new System.Drawing.Point(79, 40);
            this.cb_teamHome.Name = "cb_teamHome";
            this.cb_teamHome.Size = new System.Drawing.Size(284, 33);
            this.cb_teamHome.TabIndex = 0;
            this.cb_teamHome.SelectedIndexChanged += new System.EventHandler(this.cb_teamHome_SelectedIndexChanged);
            // 
            // cb_teamAway
            // 
            this.cb_teamAway.FormattingEnabled = true;
            this.cb_teamAway.Location = new System.Drawing.Point(750, 40);
            this.cb_teamAway.Name = "cb_teamAway";
            this.cb_teamAway.Size = new System.Drawing.Size(284, 33);
            this.cb_teamAway.TabIndex = 1;
            this.cb_teamAway.SelectedIndexChanged += new System.EventHandler(this.cb_teamAway_SelectedIndexChanged);
            // 
            // lbl_vs
            // 
            this.lbl_vs.AutoSize = true;
            this.lbl_vs.Location = new System.Drawing.Point(540, 48);
            this.lbl_vs.Name = "lbl_vs";
            this.lbl_vs.Size = new System.Drawing.Size(40, 25);
            this.lbl_vs.TabIndex = 2;
            this.lbl_vs.Text = "VS";
            // 
            // lbl_manager1
            // 
            this.lbl_manager1.AutoSize = true;
            this.lbl_manager1.Location = new System.Drawing.Point(74, 146);
            this.lbl_manager1.Name = "lbl_manager1";
            this.lbl_manager1.Size = new System.Drawing.Size(103, 25);
            this.lbl_manager1.TabIndex = 3;
            this.lbl_manager1.Text = "Manager:";
            // 
            // lbl_manager2
            // 
            this.lbl_manager2.AutoSize = true;
            this.lbl_manager2.Location = new System.Drawing.Point(745, 146);
            this.lbl_manager2.Name = "lbl_manager2";
            this.lbl_manager2.Size = new System.Drawing.Size(103, 25);
            this.lbl_manager2.TabIndex = 4;
            this.lbl_manager2.Text = "Manager:";
            // 
            // lbl_managerName1
            // 
            this.lbl_managerName1.AutoSize = true;
            this.lbl_managerName1.Location = new System.Drawing.Point(198, 146);
            this.lbl_managerName1.Name = "lbl_managerName1";
            this.lbl_managerName1.Size = new System.Drawing.Size(19, 25);
            this.lbl_managerName1.TabIndex = 5;
            this.lbl_managerName1.Text = "-";
            // 
            // lbl_managerName2
            // 
            this.lbl_managerName2.AutoSize = true;
            this.lbl_managerName2.Location = new System.Drawing.Point(873, 146);
            this.lbl_managerName2.Name = "lbl_managerName2";
            this.lbl_managerName2.Size = new System.Drawing.Size(19, 25);
            this.lbl_managerName2.TabIndex = 6;
            this.lbl_managerName2.Text = "-";
            // 
            // lbl_captain1
            // 
            this.lbl_captain1.AutoSize = true;
            this.lbl_captain1.Location = new System.Drawing.Point(74, 235);
            this.lbl_captain1.Name = "lbl_captain1";
            this.lbl_captain1.Size = new System.Drawing.Size(92, 25);
            this.lbl_captain1.TabIndex = 7;
            this.lbl_captain1.Text = "Captain:";
            // 
            // lbl_captainName1
            // 
            this.lbl_captainName1.AutoSize = true;
            this.lbl_captainName1.Location = new System.Drawing.Point(172, 235);
            this.lbl_captainName1.Name = "lbl_captainName1";
            this.lbl_captainName1.Size = new System.Drawing.Size(19, 25);
            this.lbl_captainName1.TabIndex = 8;
            this.lbl_captainName1.Text = "-";
            // 
            // lbl_captain2
            // 
            this.lbl_captain2.AutoSize = true;
            this.lbl_captain2.Location = new System.Drawing.Point(745, 235);
            this.lbl_captain2.Name = "lbl_captain2";
            this.lbl_captain2.Size = new System.Drawing.Size(92, 25);
            this.lbl_captain2.TabIndex = 9;
            this.lbl_captain2.Text = "Captain:";
            // 
            // lbl_captainName2
            // 
            this.lbl_captainName2.AutoSize = true;
            this.lbl_captainName2.Location = new System.Drawing.Point(853, 235);
            this.lbl_captainName2.Name = "lbl_captainName2";
            this.lbl_captainName2.Size = new System.Drawing.Size(19, 25);
            this.lbl_captainName2.TabIndex = 10;
            this.lbl_captainName2.Text = "-";
            // 
            // lbl_stadium
            // 
            this.lbl_stadium.AutoSize = true;
            this.lbl_stadium.Location = new System.Drawing.Point(393, 384);
            this.lbl_stadium.Name = "lbl_stadium";
            this.lbl_stadium.Size = new System.Drawing.Size(96, 25);
            this.lbl_stadium.TabIndex = 11;
            this.lbl_stadium.Text = "Stadium:";
            // 
            // lbl_capacity
            // 
            this.lbl_capacity.AutoSize = true;
            this.lbl_capacity.Location = new System.Drawing.Point(393, 465);
            this.lbl_capacity.Name = "lbl_capacity";
            this.lbl_capacity.Size = new System.Drawing.Size(102, 25);
            this.lbl_capacity.TabIndex = 12;
            this.lbl_capacity.Text = "Capacity:";
            // 
            // lbl_stadiunName
            // 
            this.lbl_stadiunName.AutoSize = true;
            this.lbl_stadiunName.Location = new System.Drawing.Point(514, 384);
            this.lbl_stadiunName.Name = "lbl_stadiunName";
            this.lbl_stadiunName.Size = new System.Drawing.Size(19, 25);
            this.lbl_stadiunName.TabIndex = 13;
            this.lbl_stadiunName.Text = "-";
            // 
            // lbl_capacityCount
            // 
            this.lbl_capacityCount.AutoSize = true;
            this.lbl_capacityCount.Location = new System.Drawing.Point(514, 465);
            this.lbl_capacityCount.Name = "lbl_capacityCount";
            this.lbl_capacityCount.Size = new System.Drawing.Size(19, 25);
            this.lbl_capacityCount.TabIndex = 14;
            this.lbl_capacityCount.Text = "-";
            // 
            // lbl_skorHome
            // 
            this.lbl_skorHome.AutoSize = true;
            this.lbl_skorHome.Location = new System.Drawing.Point(514, 747);
            this.lbl_skorHome.Name = "lbl_skorHome";
            this.lbl_skorHome.Size = new System.Drawing.Size(19, 25);
            this.lbl_skorHome.TabIndex = 18;
            this.lbl_skorHome.Text = "-";
            // 
            // lbl_tanggalTanding
            // 
            this.lbl_tanggalTanding.AutoSize = true;
            this.lbl_tanggalTanding.Location = new System.Drawing.Point(514, 666);
            this.lbl_tanggalTanding.Name = "lbl_tanggalTanding";
            this.lbl_tanggalTanding.Size = new System.Drawing.Size(19, 25);
            this.lbl_tanggalTanding.TabIndex = 17;
            this.lbl_tanggalTanding.Text = "-";
            // 
            // lbl_skor
            // 
            this.lbl_skor.AutoSize = true;
            this.lbl_skor.Location = new System.Drawing.Point(427, 747);
            this.lbl_skor.Name = "lbl_skor";
            this.lbl_skor.Size = new System.Drawing.Size(62, 25);
            this.lbl_skor.TabIndex = 16;
            this.lbl_skor.Text = "Skor:";
            // 
            // lbl_tanggal
            // 
            this.lbl_tanggal.AutoSize = true;
            this.lbl_tanggal.Location = new System.Drawing.Point(393, 666);
            this.lbl_tanggal.Name = "lbl_tanggal";
            this.lbl_tanggal.Size = new System.Drawing.Size(96, 25);
            this.lbl_tanggal.TabIndex = 15;
            this.lbl_tanggal.Text = "Tanggal:";
            // 
            // btn_check
            // 
            this.btn_check.Location = new System.Drawing.Point(375, 559);
            this.btn_check.Name = "btn_check";
            this.btn_check.Size = new System.Drawing.Size(175, 46);
            this.btn_check.TabIndex = 19;
            this.btn_check.Text = "Check";
            this.btn_check.UseVisualStyleBackColor = true;
            this.btn_check.Click += new System.EventHandler(this.btn_check_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(79, 833);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(1385, 594);
            this.dataGridView1.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(574, 747);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 25);
            this.label1.TabIndex = 21;
            this.label1.Text = "-";
            // 
            // lbl_skorAway
            // 
            this.lbl_skorAway.AutoSize = true;
            this.lbl_skorAway.Location = new System.Drawing.Point(638, 747);
            this.lbl_skorAway.Name = "lbl_skorAway";
            this.lbl_skorAway.Size = new System.Drawing.Size(19, 25);
            this.lbl_skorAway.TabIndex = 22;
            this.lbl_skorAway.Text = "-";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(3424, 1599);
            this.Controls.Add(this.lbl_skorAway);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btn_check);
            this.Controls.Add(this.lbl_skorHome);
            this.Controls.Add(this.lbl_tanggalTanding);
            this.Controls.Add(this.lbl_skor);
            this.Controls.Add(this.lbl_tanggal);
            this.Controls.Add(this.lbl_capacityCount);
            this.Controls.Add(this.lbl_stadiunName);
            this.Controls.Add(this.lbl_capacity);
            this.Controls.Add(this.lbl_stadium);
            this.Controls.Add(this.lbl_captainName2);
            this.Controls.Add(this.lbl_captain2);
            this.Controls.Add(this.lbl_captainName1);
            this.Controls.Add(this.lbl_captain1);
            this.Controls.Add(this.lbl_managerName2);
            this.Controls.Add(this.lbl_managerName1);
            this.Controls.Add(this.lbl_manager2);
            this.Controls.Add(this.lbl_manager1);
            this.Controls.Add(this.lbl_vs);
            this.Controls.Add(this.cb_teamAway);
            this.Controls.Add(this.cb_teamHome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cb_teamHome;
        private System.Windows.Forms.ComboBox cb_teamAway;
        private System.Windows.Forms.Label lbl_vs;
        private System.Windows.Forms.Label lbl_manager1;
        private System.Windows.Forms.Label lbl_manager2;
        private System.Windows.Forms.Label lbl_managerName1;
        private System.Windows.Forms.Label lbl_managerName2;
        private System.Windows.Forms.Label lbl_captain1;
        private System.Windows.Forms.Label lbl_captainName1;
        private System.Windows.Forms.Label lbl_captain2;
        private System.Windows.Forms.Label lbl_captainName2;
        private System.Windows.Forms.Label lbl_stadium;
        private System.Windows.Forms.Label lbl_capacity;
        private System.Windows.Forms.Label lbl_stadiunName;
        private System.Windows.Forms.Label lbl_capacityCount;
        private System.Windows.Forms.Label lbl_skorHome;
        private System.Windows.Forms.Label lbl_tanggalTanding;
        private System.Windows.Forms.Label lbl_skor;
        private System.Windows.Forms.Label lbl_tanggal;
        private System.Windows.Forms.Button btn_check;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_skorAway;
    }
}

